import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

/**
 * 
 */

/**
 * @author mbuguamg
 *
 */
public class KWArrayListTest {
	KWArrayList<String> list;
	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		list =  new KWArrayList<String>();
		list.add("Mickey");
		list.add("Minnie");
		list.add("Goofy");
		list.add("Mickey");
		list.add("Minnie");
		list.add("Pete");

	}
	@Test
	public void testKWArrayListInt() {
		KWArrayList<String> templist = new KWArrayList<String>(13);
		assertEquals(0, templist.size());
		//templist.add("Ferrari");
		//templist.add("Porshe");
		//assertEquals(1, templist.size());
	}

	/**
	 * Test method for {@link KWArrayList#clear()}.
	 */
	@Test
	public void testClear() {
		list.clear();
		assertEquals(true, list.isEmpty());
	}

	/**
	 * Test method for {@link KWArrayList#set(int, java.lang.Object)}.
	 */
	@Test(expected = ArrayIndexOutOfBoundsException.class)
	public void testSet() {
		assertEquals("Minnie", list.set(1, "Pluto"));
		assertEquals("Goofy", list.set(2, "Bloopy"));
		list.set(15, "Winnie");
	}

	/**
	 * Test method for {@link KWArrayList#add(int, java.lang.Object)}.
	 */
	@Test (expected = ArrayIndexOutOfBoundsException.class)
	public void testAddIntE() {
		assertEquals(true, list.add(3, "Duck"));
		list.add(7, "Daisy");
		list.add(-1, "Pete");
	}

	/**
	 * Test method for {@link KWArrayList#indexOf(java.lang.Object)}.
	 */
	@Test
	public void testIndexOf() {
		assertEquals(0, list.indexOf("Mickey"));
		assertEquals(2, list.indexOf("Goofy"));
		assertEquals(-1, list.indexOf("Mooffy"));
		assertEquals(6, list.indexOf(null));
	}

	/**
	 * Test method for {@link KWArrayList#contains(java.lang.Object)}.
	 */
	@Test
	public void testContains() {
		assertEquals(true, list.contains("Mickey"));
		assertEquals(false, list.contains("Max Goof"));
		//assertEquals(true, list.contains(null));
	}

	/**
	 * Test method for {@link KWArrayList#isEmpty()}.
	 */
	@Test
	public void testIsEmpty() {
		assertEquals(false, list.isEmpty());
		list.clear();
		assertEquals(true, list.isEmpty());
		
	}

	/**
	 * Test method for {@link KWArrayList#lastIndexOf(java.lang.Object)}.
	 */
	@Test
	public void testLastIndexOf() {
		assertEquals(-1, list.lastIndexOf("Max Goof"));
		assertEquals(3, list.lastIndexOf("Mickey"));
		assertEquals(4, list.lastIndexOf("Minnie"));
		//assertEquals(9, list.lastIndexOf(null));
		
	}

	/**
	 * Test method for {@link KWArrayList#remove(java.lang.Object)}.
	 */
	@Test
	public void testRemoveE() {
		assertEquals(true, list.remove(null));
		assertEquals(true, list.remove("Mickey"));
		assertEquals(false, list.remove("Hello"));
	}

}
