/*
 Name: Moses Mbugua
  Assignment: Lab 08
  Title: BoggleBoard
  Course: CSCI 270
  Lab Section: Lab 01
  Semester: Fall, 2016
  Instructor: Dr. Blaha
  Date: 11/4/2016
  Sources consulted: class textbook, lecture notes
  Program description: plays a boggleboard problem
  Known Bugs: the method for checking the boggleboard does not work
*/
public class BoggleMain {

	public static void main(String[] args){
		Dictionary dict = new Dictionary("words.txt");
		
		BoggleBoard board = new BoggleBoard("board.txt");
		
		Decision decision = new Decision(board, dict);
	}
	
}
