import java.util.Scanner;

public class Decision {
	private BoggleBoard brd = null;
	private Dictionary dict = null;
	private int score;
	
	Decision(BoggleBoard board, Dictionary dict){
		this.brd = board;
		this.dict = dict;
		score = 0;
		
		this.run();
	}
	
	/**
	 * Method for making board decisions
	 */
	private void run(){
		Scanner sc = new Scanner(System.in);
		String word;
		boolean goOn = true;
		while(goOn){
			brd.displayBoard();
			System.out.println("Enter a word: ");
			word = sc.nextLine();
			if(!word.isEmpty()){
				results(word);
			}
			else{
				System.out.println("Total score: " + score);
				goOn = false;
			}
		}
		
	}
	
	private void results(String word){
		int tempscore;
		if(word.length() < 3){
			System.out.printf("The word %s is too short", word);
		}
		else if(dict.searchDict(word) == false){
			System.out.printf("The word %s is not a valid word", word);
		}
		else if(dict.searchDict(word) == true && brd.checkBoard(word) == false){
			System.out.printf("The word %s is a valid word, but is not on the board", word);
		}
		else{
			tempscore = brd.countScore(word);
			score += tempscore;
			System.out.println("The word %s is good! You score " + tempscore + " points");
		}
	}
}
