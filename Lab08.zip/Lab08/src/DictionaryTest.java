import static org.junit.Assert.*;

import java.io.FileNotFoundException;

import org.junit.Before;
import org.junit.Test;

public class DictionaryTest {
	Dictionary dict = null;// normal size one
	Dictionary dict2 = null;// small one
	Dictionary dict3 = null;//empty dictionary

	@Before
	public void setUp() throws Exception {
		dict = new Dictionary("words.txt");
		dict2 = new Dictionary("smalldict.txt");
		//dict3 = new Dictionary(); need to consider if i need to create a constructor for when the 
		
	}

	@Test
	public void testDictionary() {
		Dictionary temp = new Dictionary("smalldict.txt");
		assertEquals(4, temp.size());
		
		//dict3 = new Dictionary("empty.txt");
		//assertEquals(0, dict3.size());
	}
	
	@Test
	(expected = FileNotFoundException.class)
	public void testDictionary2(){
		Dictionary temp = new Dictionary("nowords.txt");
	}

	@Test
	public void testToString() {
		assertEquals("[bonjour, hello, hola, jumbo]", dict2.toString());
		//assertEquals("[]", dict3.toString());
	}

	@Test
	public void testSearchDict(){
		assertTrue(dict.searchDict("abhor"));
		assertFalse(dict.searchDict("xyz"));
		assertFalse(dict.searchDict("a"));
		assertTrue(dict.searchDict("circumnavigations"));
		
	}
	
	@Test
	public void testSearchDict2(){
		assertTrue(dict2.searchDict("hello"));
		assertFalse(dict2.searchDict("bienvenue"));
		assertFalse(dict2.searchDict("hi"));
		assertTrue(dict2.searchDict("bonjour"));
		assertTrue(dict2.searchDict("jumbo"));
	}
	
	@Test
	public void testSize(){
		assertEquals(4, dict2.size());
		//assertEquals(0, dict3.size());
	}
}
