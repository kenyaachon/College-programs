import static org.junit.Assert.*;

import java.io.FileNotFoundException;

import org.junit.Before;
import org.junit.Test;

/**
 * 
 */

/**
 * @author mbuguamg
 *
 */
public class BoggleBoardTest {
	BoggleBoard board = null; //normal board
	BoggleBoard board2 = null;//empty board
	BoggleBoard temp = null;

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		board = new BoggleBoard("board.txt");
		board2 = new BoggleBoard("noBoard.txt");
		
	}

	/**
	 * Test method for {@link BoggleBoard#BoggleBoard(java.lang.String)}.
	 */
	@Test
	public void testBoggleBoard() {
		//BoggleBoard 
		BoggleBoard temp = new BoggleBoard("board2.txt");
		assertEquals(5, temp.boardSize());
		assertEquals(5, temp.inboardSize(0));
		assertEquals(5, temp.inboardSize(1));
		assertEquals(5, temp.inboardSize(2));
		assertEquals(5, temp.inboardSize(3));
		assertEquals(5, temp.inboardSize(4));
		
	}
	
	/**
	 * Test method for {@link BoggleBoard#BoggleBoard(java.lang.String)}.
	 */
	@Test (expected = FileNotFoundException.class)
	public void testBoggleBoard2() {
		temp = new BoggleBoard("empty.txt");
	}

	/**
	 * Test method for {@link BoggleBoard#countScore()}.
	 */
	@Test
	public void testCountScore() {
		assertEquals(1, board.countScore("hit"));
		assertEquals(5, board.countScore("benthic"));
		assertEquals(2, board.countScore("water"));
		assertEquals(11, board.countScore("circumnavigations"));
	}

	
	/**
	 * Test method for {@link BoggleBoard#checkBoard(java.lang.String)}.
	 */
	@Test
	public void testCheckBoard() {
		assertFalse(board.checkBoard("tv"));
		assertFalse(board.checkBoard(" "));
		
		
		assertTrue(board.checkBoard("hit"));
		assertTrue(board.checkBoard("benthic"));
		
		assertTrue(board.checkBoard("aeh"));
		assertFalse(board.checkBoard("water"));
		
	}
	
	/**
	 * Test method for {@link BoggleBoard#checkBoard(java.lang.String)}.
	 */
	@Test
	public void testCheckBoard2() {
		assertFalse(board2.checkBoard("String"));
		assertFalse(board2.checkBoard(" "));
	}

	/**
	 * Test method for {@link BoggleBoard#boardSize(java.lang.boardSize)}.
	 */
	@Test
	public void testBoardSize(){
		assertEquals(4, board.boardSize());
		assertEquals(0, board2.boardSize());
	}
	
	/**
	 * Test methof for {@link BoggleBoard#inBoardSize(java.lang.inBoardSize)}
	 */
	@Test
	public void testinBoardSize(){
		//checks that all the inner arrays are correct
		assertEquals(4, board.inboardSize(0));
		assertEquals(4, board.inboardSize(1));
		assertEquals(4, board.inboardSize(2));
		assertEquals(4, board.inboardSize(3));
	}
}
