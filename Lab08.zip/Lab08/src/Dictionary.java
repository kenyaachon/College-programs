import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Dictionary {
	
	//List holding all of the words from the files
	private ArrayList<String> dict;
	private String fileName;
	
	/*
	 * Constructor
	 */
	public Dictionary(String fileName){
		this.fileName = fileName;
		dict = new ArrayList<String>();
		
		this.readFile(fileName);
	}

	/**
	 * reads the inputs of a file and inputs the data into the ArrayList dict
	 * @param fileName, the name of file to be read
	 * @throws FileNotFoundException, if the specified file is not reachable
	 */
	private void readFile(String fileName){
		Scanner sc = null;
		try{
			sc = new Scanner(new File(fileName));
			while(sc.hasNext()){
				dict.add(sc.next());
			}
		}catch(FileNotFoundException e){
			System.out.println("File " + fileName + " is not found");
			}
		sc.close();
	}
	
	/**
	 * Allows you to display the list
	 * @return, a String representation of the String
	 */
	public String toString(){
		StringBuilder sb = new StringBuilder();
		sb.append("[");
		for(int i = 0; i < size(); i++){
			sb.append(dict.get(i));
			if(i != size() - 1)
				sb.append(", ");
		}
		sb.append("]");
		return sb.toString();
	}
	
	/**
	 * Searches the dictionary for a word
	 * @param search, the word to be searched for
	 * @return, returns whether a certain word is in the dictionary
	 */
	public boolean searchDict(String search){
		/*
		if(dict.contains(search))
			return true;
		return false;
		*/
		int result = searchDict(search, 0, dict.size() - 1);
		if(result != -1){
			return true;
		}
		return false;
	}
	
	/**
	 * Recursive search method
	 * @param search, the word being looked for
	 * @param first, the position of the first item
	 * @param last, the position of the last item
	 * @return whether an item is in the arrayList
	 */
	private int searchDict(String search, int first, int last){
		if (first > last)
			return -1;
		else {
			int middle = (first + last)/2;
			int compResult = search.compareTo(dict.get(middle));
			if (compResult == 0)
				return middle;
			else if (compResult < 0)
				return searchDict(search, first, middle - 1);
			else 
				return searchDict(search, middle + 1, last);
		}
	}
	/**
	 * shows the size of the dictionary
	 * @return size of the dictionary
	 */
	public int size(){
		return dict.size();
	}
	
	/**
	 * maybe add a method for adding new elements to the dictionary
	 */
}
