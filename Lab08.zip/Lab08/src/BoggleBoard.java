import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class BoggleBoard {
	
	private int size;// num of columns and rows
	
	private String fileName;// name of file with the board
	
	private Character[][] board;//data structure of the elements of the board
	
	/**
	 * Constructor
	 * @param file name of boggleboard
	 */
	public BoggleBoard(String fileName){
		this.fileName = fileName;
		
		this.createBoard(fileName);
	}
	
	/**
	 * +-------+
     * |A E H X|
     * |A I T N|
	 * |S E C E|
     * |A W T B|
     * +-------+
	 * gives a visual representation of the boggleboard game
	 */
	public void displayBoard(){
		StringBuilder sb = new StringBuilder();
		sb.append('+');
		for(int i = 0; i < size*2 -1; i++){
			sb.append('-');
		}
		sb.append('+');
		String result = sb.toString();
		System.out.println();
		System.out.println(result);
		
		sb.setLength(0);
		
		for(int r = 0; r < size; r++){
			sb.append('|');
			for(int c = 0; c < size - 1; c++){
				sb.append(board[r][c]);
				sb.append(' ');
			}
			sb.append(board[r][size-1]);
			sb.append('|');
			System.out.println(sb.toString());
			sb.setLength(0);
		}
		System.out.println(result);
	}
	
	/**
	 * creates the board from a given file
	 * @param fileName, the file name to be looked at
	 * @throws FileNotFoundExpcetion, if the file fileName is not accessible
	 */
	private  void createBoard(String fileName){
		Scanner infile = null;
		try{
		infile = new Scanner(new File(fileName));
		size = infile.nextInt();
		board = new Character[size][size];
		
		for(int r = 0;  r < size; r++) {
		  for(int c = 0; c < size; c++) {
		  	board[r][c] = infile.next().charAt(0);
		 }
		}
		} catch(FileNotFoundException e){
			System.out.println("File " + fileName + " not found");
		}
		infile.close();
	}
	
	/**
	 * Tells how well a player is doing with their score
	 * @param search, the word to be scored
	 * @return, the current score of the person who is play 
	 */
	public int countScore(String search){
		if(search.length() == 3 || search.length() == 4)
			return 1;
		if(search.length() == 5)
			return 2;
		if(search.length() == 6)
			return 3;
		if(search.length() == 7)
			return 5;
		if(search.length() >= 8)
			return 11;
		return 0;
	}
	
	/**
	 * Checks is a given word exists on the board
	 * @param search
	 * @return, true if the word is on the board
	 */
	public boolean checkBoard(String search){
		if(search.length() < 3){
			return false;
		}
		if(board.length == 0){
			return false;
		}
		else{
			//String temp = search.toUpperCase();
			for(int r = 0; r < size; r++){
				for(int c = 0; c < size; c++){
					if(checkBoard(search, r, c))
						return true;
				}
			}
		}
		return false;
	}
	
	/**
	 * the recursive method for checking if a word exists on the board
	 * @param search
	 * @param r, row we are considering
	 * @param c, column we are considering 
	 * @return, whether the word specified is in the board
	 */
	private boolean checkBoard(String search, int r, int c){
		if(search.length() == 0)
			return true;
		if( r == size - 1 || c == size - 1)
			return false;
		if(board[r][c] != search.charAt(0))
			return false;
		
		board[r][c] = '*';
		String s1 = search.substring(1);
		if(checkBoard(s1, r, c-1)){
			board[r][c] = search.charAt(0);
			return true;
		}
		if(checkBoard(s1, r - 1, c - 1)){
			board[r][c] = search.charAt(0);
			return true;
		}
		if(checkBoard(s1, r, c)){
			board[r][c] = search.charAt(0);
			return true;
		}
		if(checkBoard(s1, r + 1, c - 1)){
			board[r][c] = search.charAt(0);
			return true;
		}
		if(checkBoard(s1, r - 1, c)){
			board[r][c] = search.charAt(0);
			return true;
		}
		if(checkBoard(s1, r + 1, c)){
			board[r][c] = search.charAt(0);
			return true;
		}
		if(checkBoard(s1, r - 1, c + 1)){
			board[r][c] = search.charAt(0);
			return true;
		}
		if(checkBoard(s1, r, c + 1)){
			board[r][c] = search.charAt(0);
			return true;
		}
		if(checkBoard(s1, r + 1, c + 1)){
			board[r][c] = search.charAt(0);
			return true;
		}
		board[r][c] = search.charAt(0);
		return false;
	}

	/**
	 * Need to make a method for creating board from a dice file
	 * random selection of words
	 */
	
	/**
	 * 
	 * @return, the size of the array 
	 */
	public int boardSize(){
		return board.length;
	}
	
	/**
	 * 
	 * @param which inside array you want to check
	 * @return the size of the inside array
	 */
	public int inboardSize(int i){
		return board[i].length;
	}
	
}
