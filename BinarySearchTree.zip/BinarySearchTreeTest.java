import static org.junit.Assert.*;

import java.util.NoSuchElementException;

import javax.swing.event.TreeSelectionEvent;

import org.junit.Before;
import org.junit.Test;

public class BinarySearchTreeTest {
	BinarySearchTree<String> tree = null;//bst with 4 or more values
	BinarySearchTree<Integer> numtree = null;//bst with numbers
	BinarySearchTree<String> tree2 = null;//empty bst

	@Before
	public void setUp() throws Exception {
		tree = new BinarySearchTree<String>();
		numtree = new BinarySearchTree<Integer>();
		tree2 = new BinarySearchTree<String>();
		
		tree.add("f");
		tree.add("c");
		tree.add("j");
		tree.add("a");
		tree.add("e");
		tree.add("h");
		tree.add("b");
		tree.add("d");
		tree.add("g");
		tree.add("i");
		
		numtree.add(100);
		numtree.add(200);
		numtree.add(50);
		numtree.add(65);
		
		
	}

	@Test
	public void testToString() {
		assertEquals("(((a(b))c((d)e))f(((g)h(i))j))", tree.toString());
		assertEquals("", tree2.toString());
		assertEquals("((50(65))100(200))", numtree.toString());
	}


	@Test 
	public void testSize() {
		assertEquals(10, tree.size());
		assertEquals(0, tree2.size());
		assertEquals(4, numtree.size());
	
	}
	

	@Test
	public void testInteriorNodes() {
		assertEquals(6, tree.interiorNodes());
		assertEquals(2, numtree.interiorNodes());
		assertEquals(0, tree2.interiorNodes());
	}

	@Test
	public void testFindMin() {
		assertEquals(null, tree2.findMin());
		assertEquals("a", tree.findMin());
		assertEquals(new Integer(50), numtree.findMin());
	}

	@Test
	public void testFindMax() {
		assertEquals(new Integer(200), numtree.findMax());
		assertEquals(null, tree2.findMax());
		assertEquals("j", tree.findMax());
	}

	@Test
	public void testRemoveMin() {
		assertTrue(numtree.removeMin());
		assertTrue(tree.removeMin());
	}
	
	@Test (expected = NoSuchElementException.class)
	public void testRemoveMin2() {
		tree2.removeMin();
	}

	@Test
	public void testRemoveMax() {
		assertTrue(numtree.removeMax());
		assertTrue(tree.removeMax());
	}
	
	@Test (expected = NoSuchElementException.class)
	public void testRemoveMax2() {
		tree2.removeMax();
	}
	

	@Test
	public void testLeaves() {
		assertEquals(4, tree.leaves());
		assertEquals(2, numtree.leaves());
		assertEquals(0, tree2.leaves());
	}

	@Test
	public void testHeight() {
		assertEquals(0, tree2.height());
		assertEquals(3, numtree.height());
		assertEquals(4, tree.height());
	}

	@Test
	public void testInorder() {
		//assertEquals("f c a b e d j h g i", tree.inorder());
		assertEquals("(((a(b))c((d)e))f(((g)h(i))j))", tree.inorder());
		assertEquals("", tree2.inorder());
		assertEquals("((50(65))100(200))", numtree.inorder());
	}

	@Test
	public void testPreorder() {
		assertEquals("f c a b e d j h g i", tree.preorder());
		assertEquals("100 50 65 200", numtree.preorder());
		assertEquals("", tree2.preorder());
	}

	@Test
	public void testPostorder() {
		assertEquals("b a d e c g i h j f", tree.postorder());
		assertEquals("65 50 200 100", numtree.postorder());
		assertEquals("", tree2.postorder());
	}
	

	
	@Test
	public void testBreadthFirstOrder() {
		assertEquals("100 50 200 65", numtree.breadthFirstOrder());
		assertEquals("f c j a e h b d g i", tree.breadthFirstOrder());
		assertEquals("", tree2.breadthFirstOrder());
	}

}
