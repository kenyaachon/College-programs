import java.util.EmptyStackException;
import java.util.Stack;

/**
 Name: Moses Mbugua
  Assignment: Lab 06
  Title: Infix Evaluator
  Course: CSCI 270
  Lab Section: Lab01
  Semester: Fall, 2016
  Instructor: Dr. Blaha
  Date: October 31, 2016
  Sources consulted: class textbook, class lectures, Oracle  Java tutorial
  Program description: evaluates infix expressions including parentheses and the exponentiation operator
  Known Bugs: Not able to parse expression that have no white space
  Creativity: Have support for the modulus operator %
*/
public class InfixEvaluator {
	//stack of integers
	private static Stack<Integer> operandStack = new Stack<Integer>();
	//stack of operators
	private static Stack<Character> operatorStack = new Stack<Character>();
	
	//list of operands
	private static final String OPERATORS = "()+-*/%^";
	
	//precedence of operators
	private static final int[] PRECEDENCE = {-2, -1, 1, 1, 2, 2, 2, 3};
	
	public static void main(String[] args){
		
		/*
		//test for isOperator
		boolean multoperator = InfixEvaluator.isOperator('*');
		System.out.println(multoperator);
		boolean notoperator = InfixEvaluator.isOperator('#');
		System.out.println(notoperator);

		operandStack.push(7);
		operandStack.push(3);
		
		//test for evalop
		operatorStack.push('*');
		int evalresult = InfixEvaluator.evalOp(operatorStack.peek());
		System.out.println(evalresult);
		
		//test for precedence
		int prec = InfixEvaluator.precedence('/');
		System.out.println(prec);
		*/
		
		//test for processOperator need to be done separate from the other statements
		/*
		operandStack.push(3);
		operandStack.push(5);
		operatorStack.push('-');
		InfixEvaluator.processOperator('+');
		System.out.println(operatorStack.peek());//should be +
		System.out.println(operatorStack.size());//should be 1
		System.out.println(operandStack.peek());//should be 2
		
		operandStack.push(8);
		InfixEvaluator.processOperator('*');
		System.out.println(operandStack.peek());//should be 8
		System.out.println(operatorStack.size());// should be 2
		*/
		
		
		
	}

	/**
	 * Evaluates a give expression and gives the result of that expression
	 * @param expresion, the expression to be evaluated
	 * @return the value of the expression
	 * throw SyntaxErrorException is a syntax error is detected
	 */
	public static int evaluate(String expression) throws SyntaxErrorException{
		String[] tokens = expression.split("\\s+");
			for(String nextToken: tokens){
				char firstChar = nextToken.charAt(0);
				if(Character.isDigit(firstChar)){
					int value = Integer.parseInt(nextToken);
					operandStack.push(value);
				}
				else if(isOperator(firstChar)){
					processOperator(firstChar);
				}
				else {
					throw new SyntaxErrorException ("Invalid character encountered: " + firstChar);
				}
			}
		int result;
		while(!operatorStack.empty()){
			result = evalOp(operatorStack.pop());
			operandStack.push(result);
		}
		if(operandStack.size() > 1){
			throw new SyntaxErrorException("Illegal state: Operand Stack has more than one element");
		}
		return operandStack.pop();
	}
	/**
	 * Check whether a character is an operator like (/ + -)
	 * @param ch, the item that is going to be checked 
	 * @return if the char is an operator
	 */
	private static boolean isOperator(char ch){
		return OPERATORS.indexOf(ch) != -1;
	}
	/**
	 * Pops two operand and applies operator op to its operands
	 * @param op, the operator used on the 
	 * @return, the arthimetic result for two operands
	 */
	private static int evalOp (char op){
		int firstoperand = operandStack.pop();
		int secondoperand = operandStack.pop();
		int result = 0;
		switch(op){
		case '+': result = secondoperand + firstoperand;
				break;
		case '-': result = secondoperand - firstoperand;
				break;
		case '*': result = secondoperand * firstoperand;
				break;
		case '/': result = secondoperand / firstoperand;
				break;
		case '^': result = (int) Math.pow(secondoperand, firstoperand);
				break;
		case '%': result = secondoperand % firstoperand;
				break;
		}
		return result;
	}
	
	
	/**
	 * Checks the precedence of the operator 
	 * @param op, the operator to be checked
	 * @return, the precedenc of the value
	 */
	private static int precedence(char op){
		return PRECEDENCE[OPERATORS.indexOf(op)];
	}
	
	/**
	 * Decides how to put an operator in the operator stack
	 * @param op, the oerataor to be processed
	 */
	private static void processOperator(char firstChar){
		if(firstChar != '('){
			while(!operatorStack.empty() &&
					precedence(operatorStack.peek()) >= precedence(firstChar)){
					int result = evalOp(operatorStack.pop());
					operandStack.push(result);
			}
		}
		if(firstChar != ')'){
			operatorStack.push(firstChar);
		}
		else{
			operatorStack.pop();
		}
	}
	
}
