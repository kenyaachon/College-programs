import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class InfixEvaluatorTest {


	@Test
	public void testEvalute1() {

	}
	@Test
	public void testEvalute2() {
		assertEquals(8, InfixEvaluator.evaluate("( 7 - 3 ) * 2"));
	}
	
	@Test (expected = SyntaxErrorException.class)
	public void testEvalute3() {
		InfixEvaluator.evaluate("#$");
		InfixEvaluator.evaluate("( 3 + 5 + 3 ");
	}
	
	@Test
	public void testEvaluate4(){
		assertEquals(21, InfixEvaluator.evaluate("( 3 + 2 * 5 ) + ( 5 + 6 / 2 )"));
	}
	
	@Test 
	public void testEvaluate5(){
		assertEquals(-28, InfixEvaluator.evaluate("( 3 + 2 * 5 ) - ( 5 + 6 ^ 2 )"));
	}
	
	@Test
	public void testEvaluate6(){
		assertEquals(3, InfixEvaluator.evaluate("3 + 5 % 5"));
		assertEquals(13, InfixEvaluator.evaluate("3 + 6 % 4 * 5"));
		
	}
	
	
	
}
